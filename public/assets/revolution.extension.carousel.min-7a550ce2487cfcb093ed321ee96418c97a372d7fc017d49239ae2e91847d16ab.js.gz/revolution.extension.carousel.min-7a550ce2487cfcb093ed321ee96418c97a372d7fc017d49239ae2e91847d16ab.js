jQuery(document).ready(function($) {
	$('body').hide();
});
